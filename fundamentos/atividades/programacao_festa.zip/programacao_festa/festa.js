//informações
const adultos = parseFloat(prompt("Digite o número de adultos:"));
const criancas = parseFloat(prompt("Digite o número de crianças:"));
const horasEspaco = parseFloat(prompt("Digite quantas horas de aluguel do espaço:"));
const horasKaraoke = parseFloat(prompt("Digite quantas horas de karaokê:"));
const conjuntosMesas = parseFloat(prompt("Digite quantos conjuntos de mesas e cadeiras:"));

//consumo por pessoa
const salgadinhosPorPessoa = 18;
const docinhosPorPessoa = 6;
const refriLitrosPorPessoa = 1;
const coposPorPessoa = 5;
const pratosPorPessoa = 2;
const kitPorPessoa = 2;

//preços e custos
const precoSalgadinhos = 48.90 / 100; //por unidade
const precoDocinhos = 42.90 / 20;
const precoRefri = 8.99; //uni. de 2L
const precoCopos = 12.99 / 100;
const precoPratos = 4.99 / 10;
const precoKit = 7.99 / 10;
const precoMesas = 17.99;
const precoKaraoke = 27.99 / 2; //por horq de uso
const precoEspaco = 239.99; //por hora

const totalPessoas = adultos + criancas; //soma de todos da festa


//quantidades necessárias por pessoa
const qtdSalgadinhos = totalPessoas * salgadinhosPorPessoa;
const qtdDocinhos = totalPessoas * docinhosPorPessoa;
const qtdRefri = Math.ceil((totalPessoas * refriLitrosPorPessoa) / 2); //cada refri tem 2L - arredonda os valores para o mais prox
const qtdCopos = totalPessoas * coposPorPessoa;
const qtdPratos = totalPessoas * pratosPorPessoa;
const qtdKit = totalPessoas * kitPorPessoa;

//custos por partes
const custoSalgadinhos = qtdSalgadinhos * precoSalgadinhos;
const custoDocinhos = qtdDocinhos * precoDocinhos;
const custoRefri = qtdRefri * precoRefri;
const custoCopos = qtdCopos * precoCopos;
const custoPratos = qtdPratos * precoPratos;
const custoKit = qtdKit * precoKit;
const custoMesas = conjuntosMesas * precoMesas;
const custoKaraoke = horasKaraoke * precoKaraoke;
const custoEspaco = horasEspaco * precoEspaco;

//custos totais
const custoComunitario = custoMesas + custoKaraoke + custoEspaco;
const custoIndividual = custoSalgadinhos + custoDocinhos + custoRefri + custoCopos + custoPratos + custoKit;
const custoTotal = custoIndividual + custoComunitario;
const valorPorAdulto = custoComunitario / adultos;

alert( //mostra o relatório final com os calculos prontos
"Relatório da Festa:\n\n" +
"Salgadinhos: R$ " + custoSalgadinhos.toFixed(2) + "\n" +
"Docinhos: R$ " + custoDocinhos.toFixed(2) + "\n" +
"Refrigerantes: R$ " + custoRefri.toFixed(2) + "\n" +
"Copos: R$ " + custoCopos.toFixed(2) + "\n" +
"Pratos: R$ " + custoPratos.toFixed(2) + "\n" +
"Kit garfo/faca: R$ " + custoKit.toFixed(2) + "\n" +
"Mesas e cadeiras: R$ " + custoMesas.toFixed(2) + "\n" +
"Karaokê: R$ " + custoKaraoke.toFixed(2) + "\n" +
"Espaço: R$ " + custoEspaco.toFixed(2) + "\n\n" +
"Custo total da festa: R$ " + custoTotal.toFixed(2) + "\n" +
"Valor comunitário por adulto: R$ " + valorPorAdulto.toFixed(2)
);
